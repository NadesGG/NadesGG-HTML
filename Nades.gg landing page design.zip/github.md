repo: NadesGG/NadesGG-HTML
branch: main

## Last sync

date: 2026-09-13T12:13:19Z

### Updated in this project

- Read the live `index.html` / `style.css` for existing copy, Discord link and contact address.
- Built a new coming-soon landing page (flashbang intro + drifting smoke) on the Modernist design system.
- Vendored `styles.css` and `assets/nades-logo.png` so the page is upload-ready.

## Screen map

| Screen | Built from |
| --- | --- |
| Nades GG Landing.dc.html | index.html, style.css |
